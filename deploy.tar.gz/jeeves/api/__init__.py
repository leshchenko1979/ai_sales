"""API layer for handling external requests."""
