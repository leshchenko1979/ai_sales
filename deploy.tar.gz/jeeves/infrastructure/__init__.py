"""Infrastructure layer for configuration, logging, and other system components."""
