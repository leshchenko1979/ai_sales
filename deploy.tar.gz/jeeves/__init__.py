"""Sales bot package."""
