#!/bin/bash

set -e  # Exit on any error

# Load environment variables
if [ ! -f .env ]; then
    echo "Error: .env file not found!"
    exit 1
fi

source .env

echo "Starting deployment to ${REMOTE_HOST}..."

# Check Docker and Docker Compose installation on remote
echo "Checking Docker installation..."
ssh ${REMOTE_USER}@${REMOTE_HOST} '
    if ! command -v docker &> /dev/null; then
        echo "Docker is not installed. Installing Docker..."
        curl -fsSL https://get.docker.com -o get-docker.sh
        sudo sh get-docker.sh
        sudo usermod -aG docker $USER
        rm get-docker.sh
    fi

    if ! command -v docker compose &> /dev/null; then
        echo "Docker Compose is not installed. Installing Docker Compose..."
        sudo curl -L "https://github.com/docker/compose/releases/download/v2.23.3/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        sudo chmod +x /usr/local/bin/docker-compose
        sudo ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
    fi

    # Create traefik network if it doesnt exist
    if ! docker network ls | grep -q traefik-public; then
        echo "Creating traefik-public network..."
        docker network create traefik-public
    fi
'

# Create deployment directory
echo "Creating remote directory structure..."
ssh ${REMOTE_USER}@${REMOTE_HOST} "mkdir -p /home/jeeves/docker"

# Copy necessary files
echo "Copying Docker files..."
scp Dockerfile docker-compose.yml .dockerignore .env ${REMOTE_USER}@${REMOTE_HOST}:/home/jeeves/docker/

# Copy project files
echo "Copying project files..."
# Create a temporary tar file excluding .dockerignore patterns
tar --exclude-from=.dockerignore -czf deploy.tar.gz .
scp deploy.tar.gz ${REMOTE_USER}@${REMOTE_HOST}:/home/jeeves/docker/
ssh ${REMOTE_USER}@${REMOTE_HOST} "cd /home/jeeves/docker && tar xzf deploy.tar.gz && rm deploy.tar.gz"

# Clean up local tar file
rm deploy.tar.gz

# Build and deploy on remote using full paths
echo "Building and starting Docker container..."
ssh ${REMOTE_USER}@${REMOTE_HOST} '
    cd /home/jeeves/docker && \
    if command -v docker compose &> /dev/null; then
        docker compose down && docker compose up -d --build
    else
        /usr/local/bin/docker-compose down && /usr/local/bin/docker-compose up -d --build
    fi
'

# Check container status
echo "Checking container status..."
ssh ${REMOTE_USER}@${REMOTE_HOST} "docker ps | grep jeeves || echo 'Container not found!'"

echo "Deployment completed successfully!"
